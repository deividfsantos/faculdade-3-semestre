package com.deividsantos.trabalhoii;

import com.deividsantos.trabalhoii.graphs.Graph;

import java.util.List;

public class CastlePathBuilder {
    private boolean marked[];
    private Integer pathSize;
    private Graph g;
    private List<Castle> castles;
    private int bestPath;

    public CastlePathBuilder(Graph g, List<Castle> castles) {
        this.marked = new boolean[g.V()];
        this.g = g;
        this.castles = castles;
        this.pathSize = 0;
        this.bestPath = 0;
        buildAllPathsSize();
    }

    public int bestPath() {
        return bestPath;
    }

    private void buildAllPathsSize() {
        for (Castle castle : castles) {
            buildAllPathsSize(0, castle.getNumber(), g);
        }
    }

    private void buildAllPathsSize(Integer source, Integer destiny, Graph g) {
        marked[source] = true;
        if (source.equals(destiny)) {
            if (bestPath < pathSize) {
                bestPath = pathSize;
            }
            marked[source] = false;
            return;
        }

        for (Integer i : g.adj(source)) {
            int originalArmySize = castles.get(i).getArmySize();
            if (!marked[i] && hasEnoughArmySize(source, i)) {
                castles.get(i).setArmySize(calculateArmySizeAfterAttack(source, i));
                pathSize++;
                buildAllPathsSize(i, destiny, g);
                pathSize--;
                castles.get(i).setArmySize(originalArmySize);
            }
        }
        marked[source] = false;
    }

    private int calculateArmySizeAfterAttack(int source, int destiny) {
        Integer sourceArmySize = castles.get(source).getArmySize();
        Integer destinyArmySize = castles.get(destiny).getArmySize();
        return sourceArmySize - (destinyArmySize * 2) - 50;
    }

    private boolean hasEnoughArmySize(int source, int destiny) {
        return castles.get(destiny).getArmySize() * 2 + 100 < castles.get(source).getArmySize();
    }
}
